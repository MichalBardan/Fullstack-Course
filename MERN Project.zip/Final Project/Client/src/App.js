import { Route, Routes } from 'react-router';
import './App.css';
import { AppLayout } from './Components/AppLayout';
import { HomePage } from './Components/HomePage';
import { Layout } from './Components/Layout';
import { Login } from './Components/Login';
import { RequireAuth } from './Components/RequireAuth';
import { AddMember } from './Components/Members/AddMember';
import { EditMember } from './Components/Members/EditMember';
import { Members } from './Components/Members/Members';
import { AddMovie } from './Components/Movies/AddMovie';
import { EditMovie } from './Components/Movies/EditMovie';
import { Movies } from './Components/Movies/Movies';
import { MemberPage } from './Components/Members/MemberPage';


function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />} >

        {/* Public Routes */}
        <Route path='login' element={<Login />}/>

        {/* Protected Routes */}
        <Route element={<RequireAuth allowedRoles={[1000,2000,3000]}/>} >
          <Route path="/" element={<AppLayout />} >
            <Route path="/" element={<HomePage />} />
            <Route path='movies' element={<Movies />}/>
            <Route path='movies/:id' element={<Movies />}/>
            <Route path='addMovie' element={<AddMovie />} />
            <Route path='editMovie/:id' element={<EditMovie />} />  

            <Route path='members' element={<Members />} />
            <Route path='editMember/:id' element={<EditMember />} />
            <Route path='member/:id' element={<MemberPage />} />
          </Route>
        </Route>
        
        <Route element={<RequireAuth allowedRoles={[1000,2000]}/>} >
          <Route path="/" element={<AppLayout />} >
            <Route path='addMember' element={<AddMember />} />
          </Route>
        </Route>

      </Route> 
    </Routes>
  );
}


export default App;
