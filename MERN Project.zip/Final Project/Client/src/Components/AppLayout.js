import React, { useEffect } from 'react';
import { Outlet } from 'react-router';
import { NavBar } from './NavBar';
import { useDispatch } from 'react-redux';
import { useAxiosPrivate } from '../Hooks/useAxiosPrivate';

//Material UI
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';


export const AppLayout = () => {

  const axiosPrivate = useAxiosPrivate();
  const dispatch = useDispatch();

  const getMovies = async () => {
      let resp = await axiosPrivate.get('/movie');
      dispatch({ type : "GET_MOVIES", payload : resp.data })
  }

  const getMembers = async () => {
    let resp = await axiosPrivate.get('/member');
    dispatch({ type : "GET_MEMBERS", payload : resp.data })
  }

  const getSubs= async () => {
    let resp = await axiosPrivate.get('/subscription');
    dispatch({ type : "GET_SUB", payload : resp.data })
  }

  useEffect(() => {
    getMovies();
    getMembers();
    getSubs();
  },[])

  return (
    <main className="App">
      <NavBar />
      <Container component="main" maxWidth="md">
        <CssBaseline />
        <Box sx={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Outlet />
          </Box>
        </Container>

    </main>
  )
}
