import React from 'react';

export const HomePage = () => {

  return (
    <div>
        <h1>
        Welcome <br/><br/>
        Movie-Subscription Web Site
        </h1>

    </div>
  )
}
