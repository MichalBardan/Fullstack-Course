import { Outlet } from "react-router";


export const Layout = () => {

    return (
        <main className="App">

            <Outlet />

        </main>
    )
}