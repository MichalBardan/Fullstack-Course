import React, { useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { useAuth } from '../Hooks/useAuth';
import { useAxiosPrivate } from '../Hooks/useAxiosPrivate';

//Material UI
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';


export const Login = () => {
  const errRef = useRef();

  const axiosPrivate = useAxiosPrivate();
  const { setAuth } = useAuth();
  const loginURL = 'http://localhost:8000/api/auth';
  const [isError,setIsError] = useState(false);

  const navigate = useNavigate();
  const theme = createTheme();

    //Return To Last Visited Page After Login
      //const location = useLocation();
      //const from = location.state?.from?.pathname || "/"; 

  const [user,setUser] = useState({user: "", pwd: ""});
  const [errMsg, setErrMsg] = useState();

  const validateLogin = async (e) => {
    e.preventDefault();
    setIsError(false)
    setErrMsg('')

    try {
      const resp = await axiosPrivate.post(loginURL,user);
      const accessToken = resp?.data?.accessToken;
      const role = resp?.data?.role
      const fullName = resp?.data?.fullName
      setAuth( { user, role, accessToken, fullName })
          
       //console.log({ user, role, accessToken, fullName })
      navigate('/')
        //navigate(from, {replace : true }); 
      } catch(err) {
        setIsError(true)
        if(!err.response) {
            setErrMsg('No Server Response')
          } else if (err.response?.status === 400) {
            setErrMsg('Missing Username or Password')
          } else if (err.response?.status === 401) {
            setErrMsg('Incorrect Username or Password')
          } else {
            setErrMsg('Login Failed')
          }
        }
      setUser({ user: "", pwd: ""});
      }

  return (
    <div className="App">

    {
        isError && <Stack ref={errRef} sx={{ width: '100%' }} spacing={2}>
          <Alert severity="error">{errMsg}</Alert>
        </Stack>
    }

      <ThemeProvider theme={theme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box sx={{ marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">Sign in </Typography>
          <Box component="form" onSubmit={validateLogin} sx={{ mt: 1 }}>
            <TextField  onChange={(e)=>{setUser({...user, user: e.target.value})}}
              margin="normal"
              fullWidth
              label="Username"
              value={user.user}
            />
            <TextField required onChange={(e)=>{setUser({...user, pwd: e.target.value})}}
              margin="normal"
              fullWidth
              label="Password"
              type="password"
              value={user.pwd}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
            >
              Sign In
            </Button>
          </Box>
        </Box>
      </Container>
      </ThemeProvider>

    </div>
  )
}

