import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { useDispatch } from 'react-redux';


//Material UI
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';



export const AddMember = () => {

  const axiosPrivate = useAxiosPrivate();
  const theme = createTheme();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [alertOpen, setAlertOpen] = useState(false);
  const [member,setMember] = useState({
    Email : "",
    City : "",
    FullName : ""
  });

  const navMembers = () => {
      navigate('/members');
  };

  const handleAlertClose = () => {
    dispatch({ type:"ADD_MEMBER", payload : member });
    setAlertOpen(false);
    navigate('/members')
  };

  const addMember = async (e) => {
    e.preventDefault();
    let resp = await axiosPrivate.post('/member', member);
    if(resp?.data){
      setMember({ ...member, _id : resp.data })
      setAlertOpen(true);
  }
  };

  return (
    
    <div>
      <h1>Members</h1>
      
      <ThemeProvider theme={theme}>
        <Container component="main" maxWidth="xs" sx={{ width: 400 }}>
          <CssBaseline />
          <Box>
            <Box component="form" onSubmit={addMember}>
              <TextField required onChange={(e)=>{setMember({...member,FullName : e.target.value})}}
                size="small"
                margin="normal"
                fullWidth
                name="name"
                label="Name"/>
              <TextField required onChange={(e)=>{setMember({...member,Email : e.target.value})}}
                size="small"
                margin="normal"
                fullWidth
                name="email"
                label="Email"/>
              <TextField required onChange={(e)=>{setMember({...member,City : e.target.value})}}
                size="small"
                margin="normal"
                fullWidth
                name="city"
                label="City"/><br/><br/>
              <br/><br/>
              <Button type="submit" size="small" variant="outlined">Save</Button>&nbsp;&nbsp;
              <Button onClick={navMembers} size="small" variant="outlined">Cancel</Button><br/><br/>
            </Box>
          </Box>
        </Container>
      </ThemeProvider>

      <Dialog
        open={alertOpen}
        onClose={handleAlertClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{"Member Successfully Created!"}</DialogTitle>
        <DialogActions>
          <Button onClick={handleAlertClose} autoFocus>Close</Button>
        </DialogActions>
      </Dialog> 

    </div>
  )
}
