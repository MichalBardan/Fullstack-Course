import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { useDispatch, useSelector } from 'react-redux';


//Material UI
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Typography from '@mui/joy/Typography';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';



export const EditMember = () => {

    const axiosPrivate = useAxiosPrivate();
    const theme = createTheme();
    const [alertOpen, setAlertOpen] = useState(false);
    const params = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const storeMembers = useSelector(state => state.members);
    const [member,setMember] = useState({
        Email : "",
        City : "",
        FullName : ""
    });

    useEffect(() => {
        setMember(storeMembers.find(x => x._id == params.id));
    }, [storeMembers]);

    const updateMember = async (e) => {
        e.preventDefault();
        let resp = await axiosPrivate.put(`/member/${member._id}`,member);
        setMember({
            Email : "",
            City : "",
            FullName : ""
        });
        if(resp?.data == 'Updated!'){
            setAlertOpen(true);
            dispatch({ type:"UPDATE_MEMBER", payload : member });
        }
    };

    const handleAlertClose = () => {
        setAlertOpen(false);
        navigate('/members')
    };

    const navMembers = () => {
        navigate('/members');
    };

  return (
    <div>

        <h1>Members</h1>

        <Typography level="h2" fontSize="lg" id="card-description" mb={0.5}>Edit Member: {member.FullName} </Typography>

        <ThemeProvider theme={theme}>
            <Container component="main" maxWidth="xs" sx={{ width: 400 }}>
            <CssBaseline />
                <Box >
                    <Box component="form" onSubmit={updateMember}>
                        <TextField required onChange={(e)=> {setMember({...member,FullName:e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="name"
                        label="FullName"
                        value={member.FullName} />
                        <TextField required onChange={(e)=> {setMember({...member,Email:e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="email"
                        label="Email"
                        value={member.Email}/>
                        <TextField required onChange={(e)=> {setMember({...member,City:e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="city"
                        label="City"
                        value={member.City}/>
                        <br/><br/>

                        <Button type="submit" size="small" variant="outlined">
                        Update</Button>&nbsp;&nbsp;
                        <Button onClick={navMembers}  size="small" variant="outlined">
                        Cancel</Button><br/><br/>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider>

        <Dialog
            open={alertOpen}
            onClose={handleAlertClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description">
            <DialogTitle id="alert-dialog-title">
                {"Member Successfully Edited"}
            </DialogTitle>
            <DialogActions>
                <Button onClick={handleAlertClose} autoFocus>Close</Button>
            </DialogActions>
        </Dialog>
    </div>
  )
}
