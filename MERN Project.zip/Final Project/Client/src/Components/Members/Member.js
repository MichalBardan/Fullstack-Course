import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { MemberSubs } from './MemberSubs';

//Material UI
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import EditIcon from '@mui/icons-material/Edit';
import Card from '@mui/joy/Card';
import Typography from '@mui/joy/Typography';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';


export const Member = (props) => {

  const axiosPrivate = useAxiosPrivate();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [alertOpen, setAlertOpen] = useState(false);

  const navEditMemebr = () => {
    navigate(`/editMember/${props.member._id}`);
  };

  const deleteMember = async () => {
    let resp = await axiosPrivate.delete(`subbymember/${props.member._id}`);
    if(resp?.data == 'Deleted!'){
      setAlertOpen(true);
    }
  };

  const handleAlertClose = () => {
    dispatch({ type:"DELETE_MEMBER", payload : props.member._id });
    dispatch({ type:"DELETE_SUB_BY_MEMBER", payload : props.member._id });
    setAlertOpen(false);
  };

  return (
    <div>
      <Card variant="outlined" orientation="horizontal" sx={{ width: 272, gap: 2,
            '&:hover': { boxShadow: 'md', borderColor: 'neutral.outlinedHoverBorder' },
          }}>
        <div>
          <Typography level="h2" fontSize="lg" id="card-description" mb={0.5}>{props.member.FullName}</Typography><br/>
          <Typography fontSize="sm" sx={{ color: 'text.tertiary' }} aria-describedby="card-description" mb={1}>Email : {props.member.Email}</Typography>
          <Typography fontSize="sm" sx={{ color: 'text.tertiary' }} aria-describedby="card-description" mb={1}>City : {props.member.City}</Typography><br/>
          <div>
            <Stack style={{justifyContent: 'center'}} direction="row" spacing={2}>
              <Button onClick={navEditMemebr} size="small" variant="outlined" startIcon={<EditIcon />}>
                Edit
              </Button>
              <Button onClick={deleteMember} size="small" variant="outlined" endIcon={<DeleteIcon />}>
                Delete
              </Button>
            </Stack>
          </div><br/>
          {
            <MemberSubs member={props.member}/>
          }
        </div>
      </Card>

      <Dialog
        open={alertOpen}
        onClose={handleAlertClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{"Member Successfully Deleted!"}</DialogTitle>
        <DialogActions>
          <Button onClick={handleAlertClose} autoFocus>Close</Button>
        </DialogActions>
      </Dialog> 
    </div>
  )
}
