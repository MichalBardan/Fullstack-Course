import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { MemberSubs } from './MemberSubs';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';

//Material UI
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import EditIcon from '@mui/icons-material/Edit';
import Card from '@mui/joy/Card';
import Typography from '@mui/joy/Typography';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import Box from '@mui/material/Box';



export const MemberPage = () => {

    const axiosPrivate = useAxiosPrivate();
    const storeMembers = useSelector(state => state.members);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { id } = useParams();
    const [alertOpen, setAlertOpen] = useState(false);
    const [member, setMember] = useState({});

    const getMember = () => {
    let member = storeMembers.find(x=> x._id == id)
    setMember(member)
    };

    useEffect(() => {
        getMember();
    },[]);

    const navEditMemebr = () => {
    navigate(`/editMember/${member._id}`);
    };

    const deleteMember = async () => {
    let resp = await axiosPrivate.delete(`subbymember/${member._id}`);
    if(resp?.data == 'Deleted!'){
        setAlertOpen(true);
        }
    };

    const handleAlertClose = () => {
        dispatch({ type:"DELETE_MEMBER", payload : member._id });
        dispatch({ type:"DELETE_SUB_BY_MEMBER", payload : member._id });
        setAlertOpen(false);
        navigate('/members');
    };

  return (
    <div>
      <h1>Member</h1>

        <div>
        <Box sx={{ marginTop: 8, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
            <Card variant="outlined" orientation="horizontal" sx={{ width: 272, gap: 2,
                    '&:hover': { boxShadow: 'md', borderColor: 'neutral.outlinedHoverBorder' },
                }}>
                <div>
                <Typography level="h2" fontSize="lg" id="card-description" mb={0.5}>{member.FullName}</Typography><br/>
                <Typography fontSize="sm" sx={{ color: 'text.tertiary' }} aria-describedby="card-description" mb={1}>Email : {member.Email}</Typography>
                <Typography fontSize="sm" sx={{ color: 'text.tertiary' }} aria-describedby="card-description" mb={1}>City : {member.City}</Typography><br/>
                    <div>
                        <Stack style={{justifyContent: 'center'}} direction="row" spacing={2}>
                        <Button onClick={navEditMemebr} size="small" variant="outlined" startIcon={<EditIcon />}>
                            Edit
                        </Button>
                        <Button onClick={deleteMember} size="small" variant="outlined" endIcon={<DeleteIcon />}>
                            Delete
                        </Button>
                        </Stack>
                    </div><br/>
                    <div>
                        {
                        <MemberSubs member={member}/>
                        }
                    </div>
                </div>
            </Card>
        </Box>

        <Dialog
        open={alertOpen}
        onClose={handleAlertClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{"Member Successfully Deleted!"}</DialogTitle>
        <DialogActions>
            <Button onClick={handleAlertClose} autoFocus>Close</Button>
        </DialogActions>
        </Dialog> 
        </div>
    </div>
  )
}
