import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { Link } from 'react-router-dom';

//Material UI
import Card from '@mui/joy/Card';
import Typography from '@mui/joy/Typography';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Input from '@mui/joy/Input';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';


export const MemberSubs = (props) => {

    const axiosPrivate = useAxiosPrivate();
    const storeMovies = useSelector(state => state.movies);
    const storeSubs = useSelector(state => state.subs);
    const [memberSubs, setMemberSubs] = useState([]);
    const [sub, setSub] = useState({
        MemberId : props.member._id,
        MovieId : "DEFAULT",
        Date : ""
    });

    const getMemberSubs = () => {
        let memSubs = [];
        let subs = storeSubs.filter(x=> x.MemberId === props.member._id);
        if(subs.length > 0){
            subs.forEach(sub => {
                let movie = storeMovies.find(x=> x._id === sub.MovieId);
                if(movie){
                    movie.Date = sub.Date;
                    memSubs.push(movie)
                }
            });
            setMemberSubs(memSubs);
        }
    };


    useEffect(() => {
        setSub({ ...sub, MemberId : props.member._id })
        getMemberSubs();
    },[storeSubs, props]);



///////// Subscribe A New Movie /////////

    // Handle 'Subscribe To New Movie' button //
    const [isActive,setIsActive] = useState(false);
    const subscribeNew = () => {
        setIsActive(!isActive);
        findUnseenMovies();
    };

    // Get List of Unwatched Movies //
    const [memberUnseenMovies, setMemberUnseenMovies] = useState([]);
    const findUnseenMovies = async () => {
        let unseenMovies = [];
        storeMovies.forEach(mov => {
            if(!memberSubs.find(memMov => mov._id == memMov._id)){
                unseenMovies.push(mov)
            }
        });
        setMemberUnseenMovies(unseenMovies);
    };

    // Subscribe A New Movie // 
    const dispatch = useDispatch();
    const [alertOpen, setAlertOpen] = useState(false);

    const subscribeMovie = async (e) => {
        e.preventDefault();
        if(sub.MovieId != "DEFAULT") {
            let resp = await axiosPrivate.post('/subscription', sub);
            if(resp?.data == 'Created!'){
                setIsActive(!isActive);
                dispatch({ type:"ADD_SUB", payload : sub });
                setAlertOpen(true);
                getMemberSubs();
                setSub({
                    MemberId : props.member._id,
                    MovieId : "DEFAULT",
                    Date : ""
                });
            }
        }
    };

    const handleAlertClose = () => {
        setAlertOpen(false);
      };

const log = () => {
    console.log(props.member._id)
    console.log(sub)
}
  return (
    <div>
      <Card variant="outlined" sx={{ maxWidth: 400 }}>
        <Typography id="sub" level="body3" textTransform="uppercase" fontWeight="lg" mb={1} color="primary">
        Movies Watched
        </Typography>
        <Button onClick={subscribeNew}  size="small" variant="contained">
            Subscribe to new movie
        </Button>
            <Card sx={{ maxWidth: 400, display: isActive? 'block' : 'none' }}>
                <Box component="form" onSubmit={subscribeMovie}>
                    <Select required fullWidth size="small" defaultValue="DEFAULT" value={sub.MovieId} onChange={(e)=>{setSub({...sub, MovieId : e.target.value})}}>
                        <MenuItem disabled value="DEFAULT">--Select A Movie--</MenuItem>
                        {
                            memberUnseenMovies.map(mov => {
                                return <MenuItem key={mov._id} value={mov._id}>
                                    {mov.Name}
                                </MenuItem>
                            })
                        }
                    </Select>
                    <Input required type="date" value={sub.Date} onChange={(e)=>{setSub({...sub, Date : e.target.value})}} /><br/>
                    <Button type="submit" size="small" variant="outlined">
                        Subscribe
                    </Button>
                </Box>
            </Card>
            <ul>
                {
                    memberSubs.map((sub,index) => {
                        return <Typography id="sub" level="body3" fontWeight="lg" mb={1} key={index}>
                                    <li>
                                    <Link to={`/movies/${sub._id}`}>{sub.Name}</Link>, {sub.Date}
                                    </li></Typography> 
                    })
                }
            </ul>
      </Card>

      <Dialog
        open={alertOpen}
        onClose={handleAlertClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{"Movie Subscription Successfully Created!"}</DialogTitle>
        <DialogActions>
          <Button onClick={handleAlertClose} autoFocus>Close</Button>
        </DialogActions>
      </Dialog> 
    </div>
  )
}
