import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Member } from './Member';
import { useAuth } from "../../Hooks/useAuth";

//Material UI
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import AddIcon from '@mui/icons-material/Add';


export const Members = () => {

  // Check If Role Allowed //
  const { auth } = useAuth();
  const allowedRoles = [1000,2000];
  const isRoleAllowed = allowedRoles?.includes(auth.role);

  const navigate = useNavigate(); 
  const storeMembers = useSelector(state => state.members);

  const navAddMember = () => {
    navigate('/addMember')    
  };  

  return (
    <div>
      <h1>Subscriptions</h1>

      <div>
        {
          isRoleAllowed && <div>
              <Button onClick={navAddMember} size="small" variant="outlined" startIcon={<AddIcon />}>
              Add Member</Button><br/><br/>
            </div>
        }
       </div><br/>

      <div>
        <Box sx={{ flexGrow : 1 }}>
          <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 2, sm: 4, md: 8 }} alignItems="flex-start">
          {
                  storeMembers.map((member,index) => {
                    return <Grid xs={2} sm={4} md={4} key={index} 
                      style={{display:'flex', alignItems:'center', justifyContent:'center'}}>
                            <div><Member member={member}/>
                                  <br/><br/>
                                </div>
                            </Grid>
                    })              
                }
          </Grid>
        </Box>
      </div>
    </div>
  )
}
