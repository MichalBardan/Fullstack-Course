import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { useDispatch } from 'react-redux';

//Material UI
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import Alert from '@mui/material/Alert';
import { Collapse } from '@mui/material';


export const AddMovie = () => {

    const [movie,setMovie] = useState({
        Name : "",
        Genres : [],
        Image : "",
        YearPremiered : ""
    });

    const axiosPrivate = useAxiosPrivate();
    const theme = createTheme();
    const [alertOpen, setAlertOpen] = useState(false);
    const [validErrOpen, setValidErrOpen] = useState(false);
    const [errMsg, setErrMsg] = useState();
    const [errMsgShown, setErrMsgShown] = useState(false);
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const navMovies = () => {
        navigate('/movies')
      };

    const handleInputChange = (e) => {
        if(e.target.checked) {
            setMovie({...movie},movie.Genres.push(e.target.name))
        }
        else if (!e.target.checked) {
            let i = movie.Genres.findIndex(x=>x.name==e.target.name);
            movie.Genres.splice(i,1);
        }
    };

    const handleAlertClose = () => {
        dispatch({ type:"ADD_MOVIE", payload : movie });
        setAlertOpen(false);
        navigate('/movies')
    };

    const saveMovie = async (e) => {
        e.preventDefault();
        if(errMsgShown == false){
            let resp = await axiosPrivate.post('/movie', movie);
            if(resp?.data){
                setMovie({ ...movie, _id : resp.data });
                setAlertOpen(true);
            }
        } else {
            setValidErrOpen(true)
        }

    };

    useEffect(() => {
        if(movie.YearPremiered.length >= 5) {
            setErrMsgShown(true);
            setErrMsg('Enter year in format YYYY');
        } else if(errMsgShown) {
            setErrMsgShown(false)
            setErrMsg('')
        }
    },[movie.YearPremiered.length]);

  return (
    <div>
        <h1>Movies </h1>

        <ThemeProvider theme={theme}>
            <Container component="main" maxWidth="xs" sx={{ width: 400 }}>
            <CssBaseline />
                <Box >
                    <Box component="form" onSubmit={saveMovie}>
                        <TextField required onChange={(e)=>{setMovie({...movie,Name : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="name"
                        label="Name"
                        value={movie.Name}/>
                            <FormGroup sx={{ flexDirection: 'row'}} >
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Drama" />}
                                    label="Drama"/>
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Science-Fiction" />}
                                    label="Science-Fiction"/>
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Thriller" />}
                                    label="Thriller"/>
                            </FormGroup>
                        <TextField required onChange={(e)=>{setMovie({...movie,Image : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="img"
                        label="Image URL"
                        value={movie.Image}/>
                        <TextField required onChange={(e)=>{setMovie({...movie,YearPremiered : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="year"
                        label="Year Premiered"
                        placeholder='YYYY'
                        type="number"
                        helperText={errMsg}
                        error={movie.YearPremiered.length > 4}
                        value={movie.YearPremiered}/>
                        <br/><br/>

                        <Button type="submit" size="small" variant="outlined">
                        Save</Button>&nbsp;&nbsp;
                        <Button onClick={navMovies}  size="small" variant="outlined">
                        Cancel</Button><br/><br/>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider>

        <Dialog
            open={alertOpen}
            onClose={handleAlertClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description">
            <DialogTitle id="alert-dialog-title">
                {"Movie Successfully Created!"}
            </DialogTitle>
            <DialogActions>
                <Button onClick={handleAlertClose} autoFocus>Close</Button>
            </DialogActions>
        </Dialog> 

        <Box sx={{ width: '100%' }}>
            <Collapse in={validErrOpen}>
                <Alert severity="error" onClose={() => {setValidErrOpen(false)}}>Can't Submit Form. Check The Form Fields.</Alert>
            </Collapse>
        </Box>
    </div>
  )
}





