import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';


//Material UI
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Typography from '@mui/joy/Typography';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import Alert from '@mui/material/Alert';
import { Collapse } from '@mui/material';


export const EditMovie = () => {

    const axiosPrivate = useAxiosPrivate();
    const theme = createTheme();
    const [alertOpen, setAlertOpen] = useState(false);
    const [validErrOpen, setValidErrOpen] = useState(false);
    const [errMsg, setErrMsg] = useState();
    const [errMsgShown, setErrMsgShown] = useState(false);
    const params = useParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const storeMovies = useSelector(state => state.movies);
    const [movie,setMovie] = useState({
        Name : "",
        YearPremiered : 0,
        Image : "",
        Genres : []
    });

    useEffect(() => {
        setMovie(storeMovies.find(x => x._id == params.id));
    }, [storeMovies]);

    useEffect(() => {
        if(movie.YearPremiered.length >= 5) {
            setErrMsgShown(true);
            setErrMsg('Enter year in format YYYY');
        } else if(errMsgShown) {
            setErrMsgShown(false)
            setErrMsg('')
        }
    }, [movie.YearPremiered.length]);


    const updateMovie = async (e) => {
        e.preventDefault();
        if(errMsgShown == false){
            let resp = await axiosPrivate.put(`/movie/${movie._id}`,movie);
            if(resp?.data == 'Updated!'){
                setMovie({
                    Name : "",
                    Genres : [],
                    Image : "",
                    YearPremiered : ""
                });
                setAlertOpen(true);
                dispatch({ type:"UPDATE_MOVIE", payload : movie });
            }
        } else {
            setValidErrOpen(true);
        }
    };


    const handleInputChange = (e) => {
        if(e.target.checked) {
            setMovie({...movie},movie.Genres.push(e.target.value))
        }
        else if (!e.target.checked) {
        let i = movie.Genres.findIndex(x=>x==e.target.value);
        movie.Genres.splice(i,1);
        }
    } 

    const handleAlertClose = () => {
        setAlertOpen(false);
        navigate('/movies')
    };

    const navMovies = () => {
        navigate('/movies')
    };


  return (
    <div>    
        <h1>Movies </h1>    

        <Typography level="h2" fontSize="lg" id="card-description" mb={0.5}>Edit Movie: {movie.Name}</Typography>

        <ThemeProvider theme={theme}>
            <Container component="main" maxWidth="xs" sx={{ width: 400 }}>
            <CssBaseline />
                <Box >
                    <Box component="form" onSubmit={updateMovie}>
                        <TextField required onChange={(e)=>{setMovie({...movie,Name : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="name"
                        label="Name"
                        value={movie.Name}/>
                            <FormGroup sx={{ flexDirection: 'row'}} >
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Drama" />}
                                    label="Drama"/>
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Science-Fiction" />}
                                    label="Science-Fiction"/>
                                <FormControlLabel
                                    control={
                                    <Checkbox onChange={handleInputChange} name="Thriller" />}
                                    label="Thriller"/>
                            </FormGroup>
                        <TextField required onChange={(e)=>{setMovie({...movie,Image : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="img"
                        label="Image URL"
                        value={movie.Image}/>
                        <TextField required onChange={(e)=>{setMovie({...movie,YearPremiered : e.target.value})}}
                        size="small"
                        margin="normal"
                        fullWidth
                        name="year"
                        label="Year Premiered"
                        placeholder='YYYY'
                        type="number"
                        helperText={errMsg}
                        error={movie.YearPremiered.length > 4}
                        value={movie.YearPremiered}/>
                        <br/><br/>

                        <Button type="submit" size="small" variant="outlined">
                        Update</Button>&nbsp;&nbsp;
                        <Button onClick={navMovies}  size="small" variant="outlined">
                        Cancel</Button><br/><br/>
                    </Box>
                </Box>
            </Container>
        </ThemeProvider>

        <Dialog
            open={alertOpen}
            onClose={handleAlertClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description">
            <DialogTitle id="alert-dialog-title">
                {"Movie Successfully Edited"}
            </DialogTitle>
            <DialogActions>
                <Button onClick={handleAlertClose} autoFocus>Close</Button>
            </DialogActions>
        </Dialog> 

        <Box sx={{ width: '100%' }}>
            <Collapse in={validErrOpen}>
                <Alert severity="error" onClose={() => {setValidErrOpen(false)}}>Can't Submit Form. Check The Form Fields.</Alert>
            </Collapse>
        </Box>
        
    </div>
  )
}
