import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useAxiosPrivate } from '../../Hooks/useAxiosPrivate';
import { Sub } from './Sub';


//Material UI
import Button from '@mui/material/Button';
import DeleteIcon from '@mui/icons-material/Delete';
import Stack from '@mui/material/Stack';
import EditIcon from '@mui/icons-material/Edit';
import AspectRatio from '@mui/joy/AspectRatio';
import Card from '@mui/joy/Card';
import Typography from '@mui/joy/Typography';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';


export const Movie = (props) => {
    
    const axiosPrivate = useAxiosPrivate();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [genreLen, setGenereLen] = useState(0);
    const [alertOpen, setAlertOpen] = useState(false);

    useEffect(() => {
        setGenereLen(props.movie.Genres.length);
    },[]);

    const navEditMovie = () => {
       navigate(`/editMovie/${props.movie._id}`);      
    };

    const deleteMovie = async () => {
       let resp = await axiosPrivate.delete(`subbymovie/${props.movie._id}`);
       if(resp?.data == 'Deleted!'){
        setAlertOpen(true);
        }
    };

    const handleAlertClose = () => {
        dispatch({ type:"DELETE_MOVIE", payload : props.movie._id });
        dispatch({ type:"DELETE_SUB_BY_MOVIE", payload : props.movie._id });
        setAlertOpen(false);
    };

  return (
    <div>
        <Card variant="outlined" orientation="horizontal" 
            sx={{
                width: 400,
                gap: 2,
                '&:hover': { boxShadow: 'md', borderColor: 'neutral.outlinedHoverBorder' },
            }}>
                <AspectRatio objectFit="contain" ratio="0.7" sx={{ width: 100}} >
                    <img
                    src={props.movie.Image}
                    srcSet={props.movie.Image}
                    loading="lazy"
                    alt=""
                    />
                </AspectRatio>
            <div>
                <Typography level="h2" fontSize="lg" id="card-description" mb={0.5}>{props.movie.Name}, {props.movie.YearPremiered}</Typography>
                <Typography fontSize="sm" sx={{ color: 'text.tertiary' }} aria-describedby="card-description" mb={1}>
                    Genres: { 
                                props.movie.Genres.map((genre,index) => {
                                    if(index == genreLen-1){
                                        return `${genre} `
                                    }
                                    else {
                                        return `${genre}, `
                                    }

                                    }
                                )
                            }
                </Typography>
                    {
                        <Sub movie={props.movie}/>
                    }
                    <br/>
                <div>
                    <Stack style={{justifyContent: 'center'}} direction="row" spacing={2}>
                        <Button onClick={navEditMovie} size="small" variant="outlined" startIcon={<EditIcon />}>
                            Edit
                        </Button>
                        <Button onClick={deleteMovie} size="small" variant="outlined" endIcon={<DeleteIcon />}>
                            Delete
                        </Button>
                    </Stack>
                </div>
            </div>
        </Card>

        <Dialog
            open={alertOpen}
            onClose={handleAlertClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description">
            <DialogTitle id="alert-dialog-title">
                {"Movie And Subscriptions Deleted"}
            </DialogTitle>
            <DialogActions>
                <Button onClick={handleAlertClose} autoFocus>Close</Button>
            </DialogActions>
        </Dialog> 
    </div>
  )
}

