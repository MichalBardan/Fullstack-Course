import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router';
import { Movie } from './Movie';

//Material UI
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import Input from '@mui/joy/Input';


export const Movies = () => {
  
  const { id } = useParams();
  const navigate = useNavigate();
  const storeMovies = useSelector(state => state.movies);
  const [movies, setMovies] = useState([]);

  // Filter Movie List //
  const filterList = (e) => {
    let searchValue = e.target.value.toLowerCase();
    let filteredList = [];
    storeMovies.forEach(movie => {
      let lowName = movie.Name?.toLowerCase();
      if(searchValue === " ") {
        setMovies(storeMovies)
      }
      else if(lowName?.includes(searchValue)) {
        filteredList.push(movie)
        setMovies(filteredList)
      }
    })
  };

  // Filter Movie //
  const filterMovie = () => {
      let filterMovie = storeMovies.find(x=> x._id == id);
      setMovies([filterMovie]);
  };

  const navAddMovie = () => {
    navigate('/addMovie')
  };

  
  useEffect(() => {
    if(id) {
      filterMovie();
    } else {
      setMovies(storeMovies);
    }
  },[storeMovies, id])

  return (
      <div>
          <h1>Movies </h1>
          <Button onClick={navAddMovie} size="small" variant="outlined" startIcon={<AddIcon />}>
             Add Movie</Button>

          <Box sx={{ marginTop: 4, display: 'flex', flexDirection: 'row', alignItems: 'center',  justifyContent:'center'}}>
            <span>Find Movie:</span>&nbsp;&nbsp;
            <Input onChange={filterList} placeholder="Start typing..." variant="outlined" color="neutral" />
          </Box><br/><br/>
        
          <div>
            <Box sx={{ flexGrow : 1 }}>
              <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 2, sm: 4, md: 8 }} alignItems="flex-start">
                {
                  movies.map((movie,index) => {
                    return <Grid key={index} xs={2} sm={4} md={4} 
                      style={{display:'flex', alignItems:'center', justifyContent:'center'}}>
                            <div><Movie movie={movie}/>
                                  <br/><br/>
                                </div>
                            </Grid>
                    })         
                }
              </Grid>
            </Box>
          </div>
      </div>
  )
}


   
