import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

//Material UI
import Card from '@mui/joy/Card';
import Typography from '@mui/joy/Typography';


export const Sub = (props) => {

    const storeMembers = useSelector(state => state.members);
    const storeSubs = useSelector(state => state.subs);
    const [movieSubs, setMovieSubs] = useState([]);
    
    const getSubs = () => {
        let subs = storeSubs.filter(x=> x.MovieId == props.movie._id);
        if(subs.length > 0){
          subs.forEach(sub => {
              let member = storeMembers.find(x=> x._id == sub.MemberId);
              member.Date = sub.Date;
              setMovieSubs([ ...movieSubs, member ])
        })
      };
    };


    useEffect(() => {
        getSubs();
    },[storeSubs])


  return (
    <div style={{height:"max-content"}}>
      <Card variant="outlined" sx={{ maxWidth: 400 }}>
        <Typography id="sub" level="body3" textTransform="uppercase" fontWeight="lg" mb={1} color="primary">
        Subscriptions Watched
        </Typography>
        <ul>
          {
              movieSubs.map((sub,index) => {
                  return <Typography id="sub" level="body3" fontWeight="lg" mb={1} key={index}>
                            <li>
                              <Link to={`/member/${sub._id}`}>{sub.FullName}</Link>, {sub.Date}
                            </li></Typography> 
              })
          }
        </ul>
      </Card>
    </div>
  )
}

