import { Navigate, Outlet, useLocation } from "react-router";
import { useAuth } from "../Hooks/useAuth";

export const RequireAuth = ({ allowedRoles }) => {
    const { auth } = useAuth();
    const location = useLocation();

    return (
        allowedRoles?.includes(auth.role)
            ? <Outlet />
            : auth?.user 
                ? alert("Unauthorized")
                : <Navigate to="/login" state={{ from : location }} replace />
    );


}