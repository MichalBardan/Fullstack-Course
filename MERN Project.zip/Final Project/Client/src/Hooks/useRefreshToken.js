import { axiosPrivate } from '../api/axios';
import { useAuth } from './useAuth';

export const useRefreshToken = () => {
    const { setAuth } = useAuth();
    const refreshURL = 'http://localhost:8000/api/refresh'

    const refresh = async () => {
        const resp = await axiosPrivate.get(refreshURL)
        setAuth(prev => {
            //console.log(JSON.stringify(prev))
            //console.log(resp.data.accessToken)
            return {...prev, accessToken : resp.data.accessToken}
        })
        return resp.data.accessToken;
    }
  return refresh
}
