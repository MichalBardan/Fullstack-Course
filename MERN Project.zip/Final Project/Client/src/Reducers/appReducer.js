
const initialState = {
    movies : [],
    members : [],
    subs : []
};


const appReducer = (state = initialState, action) => {

    switch (action.type) {

        ////// Movies //////
        case "GET_MOVIES":
            return { ...state, movies : action.payload };

        case "ADD_MOVIE":
            let newMovies = [ ...state.movies, action.payload ];
            return { ...state, movies : newMovies };

        case "UPDATE_MOVIE":
            let movs = [...state.movies];
            let updateIndex = movs.findIndex(x=> x._id == action.payload._id);
            if(updateIndex >=0) {
                movs[updateIndex] = action.payload
            };
            return { ...state, movies : movs };

        case "DELETE_MOVIE":
            let delMovie = [ ...state.movies];
            let delIndex = delMovie.findIndex(x=> x._id == action.payload);
            
            if(delIndex >=0) {
                delMovie.splice(delIndex,1)
            };
            return { ...state, movies : delMovie };

        ////// Members //////
        case "GET_MEMBERS":
            return { ...state, members : action.payload };

        case "ADD_MEMBER":
            let newMem = [ ...state.members, action.payload ];
            return { ...state, members : newMem };
        
        case "UPDATE_MEMBER":
            let mem = [...state.members];
            let updateMemIndex = mem.findIndex(x=> x._id == action.payload._id);
            if(updateMemIndex >=0) {
                mem[updateMemIndex] = action.payload
            };
            return { ...state, members : mem };

        case "DELETE_MEMBER":
            let delMem = [ ...state.members];
            let delMemIndex = delMem.findIndex(x=> x._id == action.payload);
                
            if(delMemIndex >=0) {
                delMem.splice(delMemIndex,1)
            };
            return { ...state, members : delMem };

        ////// Subs //////    
        case "GET_SUB":
            return { ...state, subs : action.payload };
        
        case "ADD_SUB":
            let newSub = [ ...state.subs, action.payload ]
            return { ...state, subs : newSub };

        case "DELETE_SUB_BY_MOVIE":
            let copySubs = [ ...state.subs ]
            let newDelMovieSubs = copySubs.filter(x=> x.MovieId != action.payload)
            return { ...state, subs : newDelMovieSubs };

        case "DELETE_SUB_BY_MEMBER":
            let allSubs = [ ...state.subs ]
            let newDelMemSubs = allSubs.filter(x=> x.MemberId != action.payload)
            return { ...state, subs : newDelMemSubs };

        default:
            return state
    }
};

export default appReducer;