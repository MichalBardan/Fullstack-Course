const Member = require('../Models/memberModel');

const getAllMembers = () => {
    return Member.find({});
};

const getMember = (id) => {
    return Member.findById({ _id : id});
};

const addMember = async (obj) => {
    const m = new Member(obj);
    await m.save();
    return m._id;
};

const updateMember = async (id, obj) => {
    await Member.findByIdAndUpdate(id,obj);
    return "Updated!" 
};

const deleteMember = async (id) => {
    await Member.findByIdAndDelete(id);
    return "Deleted!" 
};


module.exports = {
    getAllMembers,
    getMember,
    addMember,
    updateMember,
    deleteMember
};

