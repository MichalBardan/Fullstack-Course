const Movie = require('../Models/movieModel');

const getAllMovies = () => {
    return Movie.find({});
};

const getMovie = (id) => {
    return Movie.findById({ _id : id});
};

const addMovie = async (obj) => {
    const m = new Movie(obj);
    await m.save()

    return m._id
};

const updateMovie = async (id, obj) => {
    await Movie.findByIdAndUpdate(id,obj);
    return "Updated!" 
};

const deleteMovie = async (id) => {
    await Movie.findByIdAndDelete(id);
    return "Deleted!" 
};

module.exports = {
    getAllMovies,
    getMovie,
    addMovie,
    updateMovie,
    deleteMovie,
};

