const Member = require('../Models/memberModel');
const Subscription = require('../Models/subscriptionModel');

const deleteSubByMember = async (id) => {
    await Promise.all([
            Member.findByIdAndDelete(id), 
            Subscription.deleteMany({ MemberId : id })
        ]); 

    return "Deleted!" 
};

module.exports = {
    deleteSubByMember
};

