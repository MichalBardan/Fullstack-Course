const Movie = require('../Models/movieModel');
const Subscription = require('../Models/subscriptionModel');

const deleteSubByMovie = async (id) => {
    await Promise.all([
        Movie.findByIdAndDelete(id),
        Subscription.deleteMany({ MovieId : id })
    ]);
    
    return "Deleted!" 
};

module.exports = {
    deleteSubByMovie
};

