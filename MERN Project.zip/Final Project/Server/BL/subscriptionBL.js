const Subscription = require('../Models/subscriptionModel');
const movieBL = require('../BL/movieBL');
const memberBL = require('../BL/memberBL');

const getAllSubscriptions = () => {
    return Subscription.find({});
};

const getSubscription = (id) => {
    return Subscription.findById({ _id : id});
};

const addSubscription = async (obj) => {
    const s = new Subscription(obj);
    await s.save();
    return "Created!"
};

const updateSubscription = async (id,obj) => {
    await Subscription.findByIdAndUpdate(id,obj)
    return "Updated!"
};

const deleteSubscription = async (id) => {
    await Subscription.findByIdAndDelete(id)
    return "Deleted!"
};



module.exports = {
    getAllSubscriptions,
    getSubscription,
    addSubscription,
    updateSubscription,
    deleteSubscription
};