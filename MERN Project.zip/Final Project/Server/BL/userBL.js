const User = require('../Models/userModel');

const getAllUsers = () => {
    return User.find({});
};

const getUser = (id) => {
    return User.findById({ _id : id});
};

const addUser = async (obj) => {
    const u = new User(obj);
    await u.save();
    return "Created!"
};

const updateUser = async (id,obj) => {
    await User.findByIdAndUpdate(id,obj);
    return "Updated!" 
};

const deleteUser = async (id) => {
    await User.findByIdAndDelete(id);
    return "Deleted!" 
};


module.exports = {
    getAllUsers,
    getUser,
    addUser,
    updateUser,
    deleteUser
};

