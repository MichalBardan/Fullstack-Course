const ROLES_LIST = {
    "Admin" : 1000,
    "Manager" : 2000,
    "Emp" : 3000
}

module.exports =  ROLES_LIST;