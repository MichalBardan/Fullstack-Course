const mongoose = require('mongoose');

const connectDB = () => {
    mongoose.connect('mongodb://127.0.0.1/ProjectDB')
    .then(() => console.log("Conneted to ProjectDB"))
    .catch((error) => console.log(error))
};


module.exports = connectDB;