const User = require('../Models/userModel');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const handleLogin = async (req,resp) => {
    const { user, pwd } = req.body;

    if(!user || !pwd) return resp.status(400).json({ 'message' : 'Username and password are required.'});

    const foundUser = await User.findOne({ Username : user});
    if(!foundUser) return resp.sendStatus(401); //Unauthorized

    //Evaluate password
    const match = (pwd === foundUser.Password)
    if(match){
        const role = foundUser.Role;
        const fullName = foundUser.Fullname;

        // JWT
        const accessToken = jwt.sign(
            { "UserInfo": {
                "username" : foundUser.Username,
                "role" : role,
                "fullName" : foundUser.Fullname
                }
            },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn : '30s' }
        );
        const refreshToken = jwt.sign(
            { "username" : foundUser.Username },
            process.env.REFRESH_TOKEN_SECRET,
            { expiresIn : '1h' }
        );

        // Save User Token 
        await User.findOneAndUpdate({Username : foundUser.Username}, { Token : refreshToken })

        // Cookie
        resp.cookie('jwt', refreshToken, { httpOnly : true, maxAge : 60 * 60 * 1000 })
        resp.json({ accessToken, role, fullName });
         
 
    } else {
        resp.sendStatus(401); //Unauthorized
    }
}

module.exports = { handleLogin };