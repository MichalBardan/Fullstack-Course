const User = require('../Models/userModel');


const handleLogout = async (req,resp) => {

    const cookies = req.cookies;
    if(!cookies?.jwt) return resp.sendStatus(201); // No Content

    const refreshToken = cookies.jwt;

    // Delete token from DB. If not found, delete cookie
    const foundUser = await User.findOneAndUpdate({ Token : refreshToken}, {Token : " "});
    if(!foundUser) {
        resp.clearCookie('jwt', { httpOnly : true});
        return resp.sendStatus(201) //No Content
    }

    resp.clearCookie('jwt', { httpOnly : true});
    resp.sendStatus(204); //No Content
}

module.exports = { handleLogout } ;