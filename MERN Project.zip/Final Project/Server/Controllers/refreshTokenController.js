const User = require('../Models/userModel');

const jwt = require('jsonwebtoken');
require('dotenv').config();

const handleRefreshToken = async (req,resp) => {
    const cookies = req.cookies;
    if(!cookies?.jwt) return resp.sendStatus(401);
    const refreshToken = cookies.jwt;

    const foundUser = await User.findOne({ Token : refreshToken});
    if(!foundUser) return resp.sendStatus(403); //Forbidden

    //Evaluate JWT
    jwt.verify(
        refreshToken,
        process.env.REFRESH_TOKEN_SECRET,
        (err, decoded) => {
            if(err || foundUser.Username !== decoded.username) return resp.sendStatus(403);
            const role = foundUser.Role;
            const accessToken = jwt.sign(
                { "UserInfo" : {
                    "username" : decoded.username,
                    "role" : role 
                    }
                }, 
                process.env.ACCESS_TOKEN_SECRET,
                { expiresIn: '30s' }
            );
            resp.json({ accessToken })
        }
    )
}

module.exports = { handleRefreshToken } ;