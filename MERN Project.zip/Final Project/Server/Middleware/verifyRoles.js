const verifyRoles = ([...allowedRoles]) => {
    
    return (req,resp,next) => {
        if(!req?.role) return resp.sendStatus(401) //Unauthorized
        const rolesArray = [...allowedRoles];

        //Handle Users Have List of Roles
        //const result = req.role.map(role => rolesArray.includes(role)).find(val = val === true);

        //Handle Users Have One Role 
        const result = rolesArray.includes(req.role);
        if(!result) return resp.sendStatus(401) //Unauthorized
        next();
    }
}

module.exports = { verifyRoles };