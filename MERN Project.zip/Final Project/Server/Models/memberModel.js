const mongoose = require('mongoose');

const memberSchema = new mongoose.Schema({
    FullName : String,
    Email : String, 
    City : String
},
{versionKey : false}
);

const Member = mongoose.model('members', memberSchema);

module.exports = Member;