const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
    Name : String,
    YearPremiered : Number,
    Genres : [String],
    Image : String
},
{versionKey : false}
);

const Movie = mongoose.model('movies', movieSchema);

module.exports = Movie;
