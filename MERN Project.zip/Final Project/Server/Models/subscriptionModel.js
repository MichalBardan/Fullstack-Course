const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
    MovieId : String,
    MemberId : String,
    Date : String
},
{versionKey : false}
);

const Subscription = mongoose.model('subscriptions', subscriptionSchema);

module.exports = Subscription;