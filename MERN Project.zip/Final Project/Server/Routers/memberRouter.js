const memberBL = require('../BL/memberBL');
const express = require('express');


const router = express.Router();

router.get('/', async (req,resp) => {
    const members = await memberBL.getAllMembers();
    resp.json(members)
});

router.get('/:id', async (req,resp) => {
    const id = req.params.id;
    const member = await memberBL.getMember(id);
    resp.json(member)
});

router.post('/', async (req,resp) => {
        const obj = req.body;
        const result = await memberBL.addMember(obj)
        resp.json(result)
});

router.put('/:id', async (req,resp) => {
    const id = req.params.id;
    const obj = req.body;
    const result = await memberBL.updateMember(id,obj);
    resp.json(result)
});

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await memberBL.deleteMember(id);
    resp.json(result)
});


module.exports = router;