const movieBL = require('../BL/movieBL');
const express = require('express');

const router = express.Router();

router.get('/', async (req,resp) => {
    const movies = await movieBL.getAllMovies();
    resp.json(movies)
});

router.get('/:id', async (req,resp) => {
    const id = req.params.id;
    const movie = await movieBL.getMovie(id);
    resp.json(movie)
});

router.post('/', async (req,resp) => {
    const obj = req.body;
    const result = await movieBL.addMovie(obj)
    resp.json(result)
});

router.put('/:id', async (req,resp) => {
    const id = req.params.id;
    const obj = req.body;
    const result = await movieBL.updateMovie(id,obj);
    resp.json(result)
});

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await movieBL.deleteMovie(id);
    resp.json(result)
});

module.exports = router;