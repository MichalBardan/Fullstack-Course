const subByMemberBL = require('../BL/subByMemberBL')
const express = require('express');

const router = express.Router();

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await subByMemberBL.deleteSubByMember(id);
    resp.json(result)
});

module.exports = router;