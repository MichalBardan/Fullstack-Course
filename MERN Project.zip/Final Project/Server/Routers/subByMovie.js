const subByMovieBL = require('../BL/subByMovieBL')
const express = require('express');

const router = express.Router();

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await subByMovieBL.deleteSubByMovie(id);
    resp.json(result)
});

module.exports = router;