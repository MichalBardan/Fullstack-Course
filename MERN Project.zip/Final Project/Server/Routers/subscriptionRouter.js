const subscriptionBL = require('../BL/subscriptionBL');
const express = require('express');

const router = express.Router();

router.get('/', async (req,resp) => {
    const subscriptions = await subscriptionBL.getAllSubscriptions();
    resp.json(subscriptions)
});

router.get('/:id', async (req,resp) => {
    const id = req.params.id;
    const subscription = await subscriptionBL.getMovie(id);
    resp.json(subscription)
});


router.post('/', async (req,resp) => {
    const obj = req.body;
    const result = await subscriptionBL.addSubscription(obj)
    resp.json(result)
});

router.put('/:id', async (req,resp) => {
    const id = req.params.id;
    const obj = req.body;
    const result = await subscriptionBL.updateSubscription(id,obj);
    resp.json(result)
});

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await subscriptionBL.deleteSubscription(id);
    resp.json(result)
});

module.exports = router;