const userBL = require('../BL/userBL');
const express = require('express');

const router = express.Router();

router.get('/', async (req,resp) => {
    const users = await userBL.getAllUsers();
    resp.json(users)
});

router.get('/:id', async (req,resp) => {
    const id = req.params.id;
    const user = await userBL.getUser(id);
    resp.json(user)
});

router.post('/', async (req,resp) => {
    const obj = req.body
    const result = await userBL.addUser(obj);
    resp.json(result)
});

router.put('/:id', async (req,resp) => {
    const id = req.params.id;
    const obj = req.body;
    const result = await userBL.updateUser(id,obj);
    resp.json(result)
});

router.delete('/:id', async (req,resp) => {
    const id = req.params.id;
    const result = await userBL.deleteUser(id);
    resp.json(result)
});


module.exports = router;