const express = require('express');
const ROLES_LIST = require('../Configs/RolesList');
const { verifyRoles } = require('../Middleware/verifyRoles');
const memberRouter = require('../Routers/memberRouter');



const router = express.Router();

router.route('/')
    .get(memberRouter)
    .post(verifyRoles([ROLES_LIST.Admin, ROLES_LIST.Manager]), memberRouter);

router.route('/:id')
    .get(memberRouter)
    .put(memberRouter)
    .delete(memberRouter)

module.exports = router;