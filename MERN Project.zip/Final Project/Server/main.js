const express = require('express');
const cors = require('cors');
const connectDB = require('./Configs/db');
const verifyJWT = require('./Middleware/verifyJWT');
const cookieParser = require('cookie-parser');
const credentials = require('./Middleware/credentials');
const corsOptions = require('./Configs/corsOptions');

const app = express();
const port = 8000;
connectDB();
app.use(express.json());
app.use(cookieParser());

//CORS
app.use(credentials)
app.use(cors(corsOptions));
//app.use(cors())

//Routing
app.use('/api/user', require('./Routers/userRouter'));
app.use('/api/auth', require('./Routers/authRouter'));
app.use('/api/refresh', require('./Routers/refreshRouter'));
app.use('/api/logout', require('./Routers/logoutRouter'));

app.use(verifyJWT);
app.use('/api/member', require('./Routers/verificationRouter'));
app.use('/api/movie', require('./Routers/movieRouter'));
app.use('/api/subscription', require('./Routers/subscriptionRouter'));
app.use('/api/subbymovie', require('./Routers/subByMovie'));
app.use('/api/subbymember', require('./Routers/subByMember'));

app.listen(port, () => {
    console.log(`app is listening at:http://localhost:${port}`)
});